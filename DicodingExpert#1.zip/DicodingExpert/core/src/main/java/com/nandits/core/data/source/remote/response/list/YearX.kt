package com.nandits.core.data.source.remote.response.list

data class YearX(
    var count: Int?,
    var nofollow: Boolean?,
    var year: Int?
)