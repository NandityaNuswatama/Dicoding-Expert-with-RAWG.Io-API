package com.nandits.core.data.source.remote.response.detail

data class StoreX(
    var domain: String?,
    var games_count: Int?,
    var id: Int?,
    var image_background: String?,
    var name: String?,
    var slug: String?
)