package com.nandits.core.data.source.remote.response.list

data class PlatformX(
    var platform: PlatformXX?,
    var released_at: String?,
    var requirements_en: Any?,
    var requirements_ru: Any?
)