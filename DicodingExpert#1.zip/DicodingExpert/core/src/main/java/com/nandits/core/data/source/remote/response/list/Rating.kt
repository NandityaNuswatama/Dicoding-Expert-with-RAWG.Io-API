package com.nandits.core.data.source.remote.response.list

data class Rating(
    var count: Int?,
    var id: Int?,
    var percent: Double?,
    var title: String?
)