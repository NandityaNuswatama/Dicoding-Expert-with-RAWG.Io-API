package com.nandits.core.data.source.remote.response.detail

data class ParentPlatform(
    var platform: Platform
)