package com.nandits.core.data.source.remote.response.list

data class AddedByStatus(
    var beaten: Int?,
    var dropped: Int?,
    var owned: Int?,
    var playing: Int?,
    var toplay: Int?,
    var yet: Int?
)