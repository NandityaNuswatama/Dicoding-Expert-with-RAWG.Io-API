package com.nandits.core.data.source.remote.response.list

data class Tag(
    var games_count: Int?,
    var id: Int?,
    var image_background: String?,
    var language: String?,
    var name: String?,
    var slug: String?
)