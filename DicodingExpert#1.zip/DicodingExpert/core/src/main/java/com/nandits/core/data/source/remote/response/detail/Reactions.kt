package com.nandits.core.data.source.remote.response.detail

data class Reactions(
    var `1`: Int?,
    var `10`: Int?,
    var `11`: Int?,
    var `12`: Int?,
    var `16`: Int?,
    var `19`: Int?,
    var `2`: Int?,
    var `21`: Int?,
    var `3`: Int?,
    var `4`: Int?,
    var `5`: Int?,
    var `6`: Int?,
    var `7`: Int?,
    var `8`: Int?,
    var `9`: Int?
)