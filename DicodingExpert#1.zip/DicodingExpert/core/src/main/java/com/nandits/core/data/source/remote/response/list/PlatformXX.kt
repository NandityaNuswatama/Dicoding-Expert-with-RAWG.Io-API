package com.nandits.core.data.source.remote.response.list

data class PlatformXX(
    var games_count: Int?,
    var id: Int?,
    var image: Any?,
    var image_background: String?,
    var name: String?,
    var slug: String?,
    var year_end: Any?,
    var year_start: Int?
)