package com.nandits.core.data.source.remote.response.detail

data class EsrbRating(
    var id: Int?,
    var name: String?,
    var slug: String?
)