package com.nandits.core.data.source.remote.response.detail

class Requirements