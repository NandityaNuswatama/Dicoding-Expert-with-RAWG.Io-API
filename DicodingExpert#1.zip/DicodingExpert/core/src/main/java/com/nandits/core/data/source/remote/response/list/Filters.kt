package com.nandits.core.data.source.remote.response.list

data class Filters(
    var years: List<Year>?
)