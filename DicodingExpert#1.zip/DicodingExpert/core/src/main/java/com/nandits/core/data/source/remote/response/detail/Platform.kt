package com.nandits.core.data.source.remote.response.detail

data class Platform(
    var id: Int?,
    var name: String,
    var slug: String?
)