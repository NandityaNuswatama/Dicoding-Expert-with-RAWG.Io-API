package com.nandits.core.data.source.remote.response.detail

data class Store(
    var id: Int?,
    var store: StoreX?,
    var url: String?
)