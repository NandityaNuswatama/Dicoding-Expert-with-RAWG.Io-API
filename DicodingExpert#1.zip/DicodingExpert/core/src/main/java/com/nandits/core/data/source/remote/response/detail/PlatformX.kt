package com.nandits.core.data.source.remote.response.detail

data class PlatformX(
    var platform: PlatformXX?,
    var released_at: String?,
    var requirements: Requirements?
)