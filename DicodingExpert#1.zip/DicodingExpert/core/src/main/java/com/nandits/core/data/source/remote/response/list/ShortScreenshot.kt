package com.nandits.core.data.source.remote.response.list

data class ShortScreenshot(
    var id: Int?,
    var image: String?
)