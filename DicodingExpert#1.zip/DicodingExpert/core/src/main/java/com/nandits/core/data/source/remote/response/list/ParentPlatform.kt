package com.nandits.core.data.source.remote.response.list

data class ParentPlatform(
    var platform: Platform
)